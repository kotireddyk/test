import { Component, OnInit } from '@angular/core';
import { AppService } from '../app.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-members',
  templateUrl: './members.component.html',
  styleUrls: ['./members.component.css']
})
export class MembersComponent implements OnInit {
  members:any = [];
  memberData:any=[];
  id;

  constructor(public appService: AppService, private router: Router) {}

  ngOnInit() {
    //Load members once you delete any member
    this.appService.getMembers().subscribe(members => (this.members = members));
    this.loadMembers();
  }

  //Add Member button functionality
  goToAddMemberForm() {
    this.router.navigate(['/memberdetails']);
  }


  // Get employees list
  loadMembers() {
    return this.appService.getMembers().subscribe((data: {}) => {
      this.members =(data);
    })
  }

  editMemberByID(ev:Event, id: number) {
      console.log('inside update', this.memberData)
  }

  //Delete Member as per selected ID
  deleteMemberById(ev:Event,id: number) {
    ev.preventDefault();
    if (window.confirm('Are you sure, you want to delete?')){
      this.appService.deleteMember(id).subscribe(data => {
        this.loadMembers();
      })
    }
  }
}

 
