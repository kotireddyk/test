import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders  } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AppService {
  api = 'http://localhost:3000';
  username: string;

  constructor(private http: HttpClient) {}

   // Http Options
   httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }

  // Returns all members
  getMembers() {
    return this.http
      .get(`${this.api}/members`)
      .pipe(catchError(this.handleError));
  }

  setUsername(name: string): void {
    this.username = name;
  }
  // HttpClient API post() method => Add Member
  addMember(memberForm):Observable<any> {  
    return this.http.post<any>(`${this.api}` + '/members', (memberForm), this.httpOptions)
    .pipe(     
      catchError(this.handleError)
    )
  }
  // HttpClient API put() method => Update Member
  updateMember(id, memberForm): Observable<any> {
    return this.http.put<any>(`${this.api}` + '/members/' + id, (memberForm), this.httpOptions)
    .pipe(catchError(this.handleError))
  }

   // HttpClient API delete() method => Delete Member
   deleteMember(id){
     console.log('deleted', id)
    return this.http.delete<any>(`${this.api}` + '/members/' + id, this.httpOptions)
    .pipe(catchError(this.handleError))
  }

  // HttpClient API get() method => Fetch Member
  getSelectedMember(id): Observable<any> {
    return this.http.get<any>(`${this.api}` + '/members/' + id)
    .pipe(catchError(this.handleError))
  }  

  // Get Team Names
  getTeams() {
    return this.http
      .get(`${this.api}/teams`)
      .pipe(catchError(this.handleError));
  }

  // Handling Errors
  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      console.error('An error occurred:', error.error.message);
    } else {
      console.error(
        `Backend returned code ${error.status}, ` + `body was: ${error.error}`
      );
    }
    return [];
  }
}
