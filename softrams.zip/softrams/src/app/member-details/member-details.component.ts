import { Component, OnInit, OnChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppService } from '../app.service';
import { Router, ActivatedRoute } from '@angular/router';

// This interface may be useful in the times ahead...
interface Member {
  firstName: string;
  lastName: string;
  jobTitle: string;
  team: string;
  status: string;
}

@Component({
  selector: 'app-member-details',
  templateUrl: './member-details.component.html',
  styleUrls: ['./member-details.component.css']
})
export class MemberDetailsComponent implements OnInit, OnChanges {
  memberModel: Member;
  memberForm: FormGroup;
  submitted = false;
  alertType: String;
  alertMessage: String;
  teams = [];
  id = (this.actRoute.snapshot.params['id']) ;
  memberData: any = {};

  constructor(private fb: FormBuilder, private appService: AppService, private router: Router,  public actRoute: ActivatedRoute) {
      this.createForm()

  }

  ngOnInit() {
    //To Get Team names in Dropdown
    this.appService.getTeams().subscribe(teams => (this.teams = teams));
    //Fetches Data for the ID to be updated
    this.appService.getSelectedMember(this.id).subscribe((data: {}) => {
      this.memberData = data;
    });
    if(this.id == 'undefined' || this.id == undefined){
      this.id = 0;
    }
  }

  // Client Side Validation
  createForm(){
    this.memberForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      jobTitle: ['', Validators.required],
      team: ['', Validators.required],
      status: ['', Validators.required]
  });
  }

  ngOnChanges() {}

   // convenience getter for easy access to form fields
   get f() { return this.memberForm.controls; }

  // TODO: Add member to members
  onSubmit(form: FormGroup) {
    this.submitted = true;  // If the form is submitted 
    this.memberModel = this.memberForm.value;  // Fetching the forms Data  
    // stop here if form is invalid
    if (this.memberForm.invalid) {
      return;
    }
  
    if(this.id != 0){  // If Update Member button is clicked
      //Update the form
        this.appService.updateMember(this.id, this.memberData).subscribe(data => {
          this.router.navigate(['/members'])
        });
    }else{  //If Add Member is clicked
      console.log(this.id)
      this.appService.addMember(this.memberModel).subscribe((data: {}) => {
        this.router.navigate(['/members']);   
    })

    }  
      
  }
}
